package com.example.button;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private int n_alerts = 0;

    private CheckBox report, emergency;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Create checkboxes buttons
        report = (CheckBox) findViewById(R.id.report);
        report.setOnClickListener(this);
        emergency = (CheckBox) findViewById(R.id.emergency);
        emergency.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

    }
    public void buttonAlert(View view) {
        if (report.isChecked() || emergency.isChecked()){
            n_alerts ++;
            if (report.isChecked()){
                Client.main(n_alerts, "report");
            } else if(emergency.isChecked()) {
                Client.main(n_alerts, "emergency");
            }else{
                Client.main(n_alerts, "both");
            }
            Toast.makeText(this, "Alert sent", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Select one of the boxes!", Toast.LENGTH_SHORT).show();
        }
    }
}