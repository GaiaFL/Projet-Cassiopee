package com.example.button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;


import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private int n_alerts = 0;
    ImageButton button_alert;
    EditText alert;

    private CheckBox report, emergency;

    int n_net = 1;

    List<WifiInfo> networks = null;
    List<WifiInfo> sortednets = null;
    Animation scaleUp, scaleDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        //Create alert button
        button_alert = findViewById(R.id.button_alert);
        //Create animations for button
        scaleUp = AnimationUtils.loadAnimation(this, R.anim.scan_up);
        scaleDown = AnimationUtils.loadAnimation(this, R.anim.scale_down);

        //Create checkboxes buttons
        report = (CheckBox) findViewById(R.id.report);
        report.setOnClickListener(this);
        emergency = (CheckBox) findViewById(R.id.emergency);
        emergency.setOnClickListener(this);


        //Text from the user
        alert = findViewById(R.id.alert);

        //Set policy of threads
        Log.d("Creation", "Starting thread policy");
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

    }

    @Override
    public void onClick(View view) {

    }

    public void createConnection(){
        //Set wifi getter
        Log.d("Creation", "Starting list of wifi connections");
        WifiGetter wifi = new WifiGetter();
        //Return list of connections
        List<ScanResult> results = wifi.getWiFiInfo(this);

       networks = new ArrayList<WifiInfo>();
        //Filter to find closest eduroam
        for(ScanResult r : results){
            System.out.println(r.SSID);
            if(r.SSID.toLowerCase().contains("eduroam")){
                if(networks.size() < n_net) {//Add only the first n_net eduroam connections
                    networks.add(new WifiInfo(r.level, r.SSID, r.BSSID));
                }
            }
        }

        System.out.println(networks);
        /*sortednets = networks.stream()
                .sorted(Comparator.comparing(WifiInfo::getRssi).reversed())
                .collect(Collectors.toList()).subList(0, n_net);*/
        //Check if network was found
        if(!networks.isEmpty()) {
            Log.d("Creation", "Found connections");
            for(WifiInfo w : networks) {
                System.out.println(w.name_router + " " + w.MAC + " " + w.rssi);
            }
        }else{
            Toast.makeText(this, "You're not connected to the eduroam network!", Toast.LENGTH_SHORT).show();
        }
    }

    public void buttonAlert(View view) {
        createConnection();
        String text_user = alert.getText().toString();
        alert.getText().clear();
        if (!networks.isEmpty()) {
            Log.d("Check", "Checking boxes");
            if (report.isChecked() || emergency.isChecked()) {
                n_alerts++;
                String type_alert;
                if (emergency.isChecked() && report.isChecked()) {
                    type_alert = "both";
                } else if (report.isChecked()) {
                    type_alert = "report";
                } else {
                    type_alert = "emergency";
                }
                Log.d("Creation", "Creating new client");
                Client c = new Client(new Message(n_alerts, type_alert, networks, text_user), this);
                Log.d("Start", "Starting thread");
                Thread thread = new Thread(c);
                thread.start();
                Toast.makeText(this, "Alert sent", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Select one of the boxes!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Enable your GPS, button failed", Toast.LENGTH_SHORT).show();
        }
    }

    public class WifiGetter implements ActivityCompat.OnRequestPermissionsResultCallback { //TO DO: GPS PERMISSION
        private static final int FINE_LOCATION_CODE = 100;
        private static final int ACCESS_WIFI_STATE_CODE = 101;
        private static final int CHANGE_WIFI_STATE_CODE = 102;
        private static final int  ACCESS_COARSE_LOCATION_CODE= 103;

        public List<ScanResult> getWiFiInfo(Context c) {
            WifiManager wifiManager = getWifiManager(c);
            if (ActivityCompat.checkSelfPermission(c, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) c, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, FINE_LOCATION_CODE);
            }
            if (ActivityCompat.checkSelfPermission(c, android.Manifest.permission.ACCESS_WIFI_STATE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) c, new String[]{android.Manifest.permission.ACCESS_WIFI_STATE}, ACCESS_WIFI_STATE_CODE);
            }
            if (ActivityCompat.checkSelfPermission(c, android.Manifest.permission.CHANGE_WIFI_STATE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) c, new String[]{android.Manifest.permission.CHANGE_WIFI_STATE}, CHANGE_WIFI_STATE_CODE);
            }
            if (ActivityCompat.checkSelfPermission(c, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) c, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, ACCESS_COARSE_LOCATION_CODE);
            }
            return wifiManager.getScanResults();
        }

        private WifiManager getWifiManager(Context c) { //Get status of wifi; if it's on or not
            WifiManager wifi = (WifiManager) c.getSystemService(WIFI_SERVICE);
            if (!wifi.isWifiEnabled()) {
                Toast.makeText(c, "eduroam wifi is disable..make it enable!", Toast.LENGTH_LONG).show();
                wifi.setWifiEnabled(true);

            }
            return wifi;
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                               @NonNull int[] grantResults) {
            if (requestCode == FINE_LOCATION_CODE) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext() , "Permission accepted", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext() , "Permission denied", Toast.LENGTH_SHORT).show();
                }
            }

        }

    }
}