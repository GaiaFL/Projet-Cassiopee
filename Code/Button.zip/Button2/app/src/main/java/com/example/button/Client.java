package com.example.button;
import java.io.*;
import java.net.*;

public class Client {

    public static void main(int number, String type_alert) {
        int serverPort = 8888;
        Socket socket = null;
        ObjectOutputStream toServer;
        ObjectInputStream fromServer;
        try {
            if(type_alert.isEmpty()){
                throw new Exception("Type of alert is empty");
            }
            InetAddress serverHost = InetAddress.getByName("localhost");
            System.out.println("Connecting to server on port " + serverPort);
            socket = new Socket(serverHost,serverPort);
            System.out.println("Just connected to " + socket.getRemoteSocketAddress());
            toServer = new ObjectOutputStream(
                    new BufferedOutputStream(socket.getOutputStream()));
            Message msgToSend = new Message(number, type_alert);
            toServer.writeObject(msgToSend);
            toServer.flush();

            // This will block until the corresponding ObjectOutputStream
            // in the server has written an object and flushed the header
            fromServer = new ObjectInputStream(
                    new BufferedInputStream(socket.getInputStream()));
            Message msgFromReply = (Message)fromServer.readObject();
            System.out.println(" Number of alerts: " + number + " was " + msgFromReply);
        }
        catch(IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        finally {
            if(socket != null) {
                try {
                    socket.close();
                }
                catch(IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
