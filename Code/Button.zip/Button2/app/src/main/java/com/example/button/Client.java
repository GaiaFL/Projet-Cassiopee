package com.example.button;

import com.google.gson.Gson;

import java.io.*;
import java.net.*;


class Client implements Runnable{
    private final Message msg;
    private String json;
    Socket socket;
    int serverPort = 80;
    String address = "10.42.46.242";
    public Client(Message msg){
        this.msg = msg;
    }
    public void run(){
        socket = null;
        ObjectOutputStream toServer;
        ObjectInputStream fromServer;
        try {
            InetAddress serverAddr = InetAddress.getByName(address);
            System.out.println("Connecting to server on port " + serverPort);
            socket = new Socket(serverAddr,serverPort);
            System.out.println("Just connected to " + socket.getRemoteSocketAddress());
            toServer = new ObjectOutputStream(
                    new DataOutputStream(socket.getOutputStream()));
            json = new Gson().toJson(msg);
            toServer.writeObject(json);
            toServer.flush();
            toServer.close();
            // This will block until the corresponding ObjectOutputStream
            // in the server has written an object and flushed the header
            /*fromServer = new ObjectInputStream(
                    new BufferedInputStream(socket.getInputStream()));
            Message msgFromReply = (Message)fromServer.readObject();*/
            System.out.println(" Number of alerts: " + msg.getNumber() );
            socket.close();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
