package com.example.button;

import android.content.Context;
import android.os.Looper;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.*;
import java.net.*;


class Client implements Runnable{
    private final Message msg;
    private String json;
    Socket socket;
    int serverPort = 80;
    String address = "192.168.96.60";

    private Context context;
    private volatile boolean value;
    public Client(Message msg, Context c){
        this.context = c;
        this.msg = msg;
    }
    public void run(){
        value = false;
        socket = null;
        ObjectOutputStream toServer;
        ObjectInputStream fromServer;
        Looper.prepare();
        try {
            InetAddress serverAddr = InetAddress.getByName(address);
            System.out.println("Connecting to server on port " + serverPort);
            socket = new Socket(serverAddr,serverPort);
            System.out.println("Just connected to " + socket.getRemoteSocketAddress());
            toServer = new ObjectOutputStream(
                    new DataOutputStream(socket.getOutputStream()));
            json = new Gson().toJson(msg);
            toServer.writeObject(json);
            value = true;
            toServer.flush();
            toServer.close();
            // This will block until the corresponding ObjectOutputStream
            // in the server has written an object and flushed the header
            /*fromServer = new ObjectInputStream(
                    new BufferedInputStream(socket.getInputStream()));
            Message msgFromReply = (Message)fromServer.readObject();*/
            System.out.println(" Number of alerts: " + msg.getNumber() );
            socket.close();
        } catch(Exception e) {
            Toast.makeText(this.context, "Socket connection failed, try again!", Toast.LENGTH_SHORT).show();
            Looper.loop();
        }
    }
    public boolean getValue() {
        return value;
    }
}
