package com.example.button;

public class WifiInfo {
    public final int rssi;
    public String name_router;
    public String MAC;

    public WifiInfo(int rssi, String address, String MAC){
        this.rssi = rssi;
        this.name_router = address;
        this.MAC = MAC;
    }

    public int getRssi() {
        return rssi;
    }
}
