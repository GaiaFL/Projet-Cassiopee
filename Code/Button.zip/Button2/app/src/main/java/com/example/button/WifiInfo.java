package com.example.button;

public class WifiInfo {
    private int rssi;
    private String name_router;
    private String MAC;

    public WifiInfo(int rssi, String address, String MAC){
        this.rssi = rssi;
        this.name_router = address;
        this.MAC = MAC;
    }
}
