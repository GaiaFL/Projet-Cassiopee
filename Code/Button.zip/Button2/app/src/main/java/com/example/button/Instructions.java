package com.example.button;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;



public class Instructions extends AppCompatActivity {

    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.instructions);


        //postDelayed method, Causes the Runnable r (in this case Class B) to be added to the message queue, to be run
        // after the specified amount of time elapses.
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //Create a new Intent to go from Class B to Class C and start the new Activity.
                Intent intent = new Intent(Instructions.this, MainActivity.class);
                startActivity(intent);
                finish();

            }
            //Here after the comma you specify the amount of time you want the screen to be delayed. 5000 is for 5 seconds.
        }, 5000);
    }

    //Override onBackPressed method and give it no functionality. This way when the user clicks the back button he will not go back.
    public void onBackPressed() {

    }
}
