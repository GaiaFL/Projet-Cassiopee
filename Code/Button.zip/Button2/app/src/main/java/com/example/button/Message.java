package com.example.button;


import java.io.Serializable;
import java.util.List;

public class Message implements Serializable {
    private final int number;
    private final String type_alert;
    private final List<WifiInfo> results;
    private final String alert;
    Message(int number, String type_alert, List<WifiInfo> results, String alert) {
        this.number = number;
        this.type_alert = type_alert;
        this.results = results;
        this.alert = alert;
    }

    public String getType_alert() {
        return type_alert;
    }

    public int getNumber() {
        return number;
    }
}
