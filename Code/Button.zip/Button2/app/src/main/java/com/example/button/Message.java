package com.example.button;

public class Message {
    private final int number;
    private final String type_alert;
    Message(int number, String type_alert) {
        this.number = number;
        this.type_alert = type_alert;
    }

    public String getType_alert() {
        return type_alert;
    }

    public int getNumber() {
        return number;
    }
}
