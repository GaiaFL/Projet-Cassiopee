package com.example.button;

import android.net.wifi.ScanResult;

import java.io.Serializable;

public class Message implements Serializable {
    private final int number;
    private final String type_alert;
    private WifiInfo result;
    private String alert = "";
    Message(int number, String type_alert, WifiInfo result, String alert) {
        this.number = number;
        this.type_alert = type_alert;
        this.result = result;
        this.alert = alert;
    }

    public String getType_alert() {
        return type_alert;
    }

    public int getNumber() {
        return number;
    }
}
